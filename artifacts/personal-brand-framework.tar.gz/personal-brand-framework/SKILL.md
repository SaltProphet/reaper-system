---
name: personal-brand-framework
description: "REAPER configuration for personal-brand market strategy. Persistent evidence-based decision engine that determines credible known-for, relevant markets/audiences, their problems, platform access, positioning, first actions, and whether to continue or change. Not a posting calendar. Trigger on personal brand market strategy, brand positioning from evidence, audience and platform fit, REAPER personal brand."
type: workflow
lifecycle: active
---

# Personal Brand Market Strategy — REAPER Configuration

REAPER is the operating system. This is the loaded application: a persistent, evidence-based decision engine for discovering, selecting, and testing a personal-brand market position.

Not a posting calendar. Not a generic social-media assistant.

## What the system determines

- What the person can credibly be known for
- Which markets or audiences are relevant
- What those people care about or struggle with
- Which platforms provide access to them
- What positioning connects the person to that market
- What to publish, offer, test, or pursue first
- Whether the results justify continuing or changing direction

## REAPER stages with personal-brand content

**R — Research**  
Markets, audiences, platforms, competitor/creator patterns, personal capabilities and credible experience.  
Input: Personal Objective + source material.  
Output: Source records with provenance.

**E — Evidence**  
Source-backed signals only.  
Every signal: Evidence ID, Source ID, Source type, URL/provenance, verbatim quote or extracted fact, detection pattern, timestamp, confidence/status.  
AI interprets; it does not invent.

**A — Analysis**  
Fit, themes, positioning hypotheses, audience interpretations, market possibilities, platform implications.  
All labeled hypotheses unless directly supported. Include validation questions and missing-evidence lists.

**P — Prioritization**  
Rank strategic options by evidence strength, frequency, relevance, constraint fit, effort, opportunity value, ability to act, risk.  
Output: ranked candidate findings, not an automatic conclusion.

**E — Execution**  
Select the highest-priority viable move: content, outreach, experiments, offers, or missing-evidence gathering.  
One primary action. No endless alternatives.

**R — Recordkeeping**  
Decision, action, evidence used, options rejected, results, failures, new evidence, next-cycle implications.

## Stage connectors

| Stage          | Input                       | Output                                                  |
| -------------- | --------------------------- | ------------------------------------------------------- |
| Research       | Objective + source material | Source records                                          |
| Evidence       | Source records              | Traceable evidence objects                              |
| Analysis       | Evidence objects            | Themes, hypotheses, audience and market interpretations |
| Prioritization | Findings                    | Ranked strategy options                                 |
| Execution      | Selected decision           | Actions and experiments                                 |
| Recordkeeping  | Action results              | Measurement evidence for the next cycle                 |

## Data object flow

```
Personal Objective
        ↓
Source Records
        ↓
Evidence Objects
        ↓
Candidate Findings
        ↓
Strategy Decision
        ↓
Action Records
        ↓
Measurement Evidence
```

## Configuration box (this domain only)

- Personal capabilities and interests
- Credible experience
- Candidate markets
- Audience problems and desires
- Platform mechanics
- Competitor and creator patterns
- Possible positioning
- Content and offer experiments
- Real-world response data

## Examples

### Example objects

**Personal Objective**
```json
{
  "objective": "Be known for reliable workflow rescue in technical services under real name Justin Strange",
  "constraints": ["real-name required", "blunt non-corporate voice", "low daily posting cost"],
  "capabilities": ["production auth systems", "n8n automation", "evidence-first operator"],
  "resources": ["existing GitHub under SaltProphet", "SecPriva LLC"]
}
```

**Source Record**
```json
{
  "source_id": "SRC-001",
  "source_type": "public_post",
  "url": "https://x.com/example/status/123",
  "retrieved_at": "2026-10-19",
  "raw_excerpt": "Spent three days debugging a broken n8n + CRM flow. No one owns the failure."
}
```

**Evidence Object**
```json
{
  "evidence_id": "EV-001",
  "source_id": "SRC-001",
  "source_type": "public_post",
  "source_url": "https://x.com/example/status/123",
  "quote": "Spent three days debugging a broken n8n + CRM flow. No one owns the failure.",
  "pattern": "ownership_gap",
  "status": "present",
  "created_at": "2026-10-19"
}
```

**Candidate Finding** (hypothesis)
```json
{
  "finding_id": "CF-001",
  "theme": "operators need someone to own broken automation failures",
  "hypothesis": "Positioning as the person who inspects, repairs, and documents failed workflows may fit boutique technical services buyers",
  "supporting_evidence": ["EV-001"],
  "validation_questions": ["Do buyers search for this explicitly?", "What is the actual willingness to pay?"],
  "missing_evidence": ["pricing quotes", "repeat purchase signals"]
}
```

**Strategy Decision**
```json
{
  "primary": "Post one public failure-diagnosis thread on X under Justin Strange",
  "secondary": "Mirror the same thread on a personal site for persistence",
  "killed": ["LinkedIn (voice mismatch)", "daily posting calendar (cost constraint)"],
  "next_action": "Publish the single thread today"
}
```

### Worked cycle (abbreviated)

1. Research → collected public complaints about broken automations and platform mechanics for X vs writing platforms.  
2. Evidence → EV-001 (ownership gap quote), EV-002 (X allows real-name blunt posts), EV-003 (writing platforms provide persistence).  
3. Analysis → hypothesis that “workflow rescue operator” is a credible known-for; platform fit favors low-frequency X + persistent site.  
4. Prioritization → single public diagnosis post ranks highest (evidence strength + ability to act + constraint fit).  
5. Execution → one post published.  
6. Recordkeeping → post URL, initial metrics, and note that engagement data is now the next cycle’s source material.

All analysis remains labeled hypothesis. No audience-size or revenue claims.

1. No evidence, no factual claim.  
2. No decision without prioritization.  
3. No completed cycle without recordkeeping.

## Output Contract

Every cycle returns:
- Evidence objects with provenance
- Analysis as hypotheses
- Ranked options
- One primary action
- Recordkeeping entry that seeds the next cycle

Stop after the decision. Do not invent audience size, engagement, or “best platform.”

## Sanity Check

- Contradictory constraints → surface and stop.  
- Multiple viable primaries → force choice by actual willingness to execute today.  
- Killed options stay killed in the cycle.  
- Measurement evidence becomes the next cycle’s source material.