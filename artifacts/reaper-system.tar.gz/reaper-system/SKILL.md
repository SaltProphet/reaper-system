---
name: reaper-system
description: "Canonical R.E.A.P.E.R. System: Research, Evidence, Analysis, Prioritization, Execution, Recordkeeping. Evidence-first operating system for research, opportunity discovery, strategy, and execution. Domain configurations include Gravemark, pain-signal-harvester, and personal-brand-framework. Trigger on REAPER, REAPER system, evidence-first operating system, research to execution loop."
type: workflow
lifecycle: active
---

# The R.E.A.P.E.R. System

A single evidence-first operating system for research, opportunity discovery, strategy, and execution.

Its job is simple:  
Turn an unclear objective into an evidence-backed decision, take action, and remember what happened.

## Stages

**R — Research**  
Define what needs to be learned and gather relevant material.  
Inputs may include: web pages, reviews, complaints, social posts, competitor information, platform mechanics, market data, personal observations, previous system records.  
Output: organized source material with provenance.

**E — Evidence**  
Separate what is actually supported from what merely sounds plausible.  
Every meaningful signal receives:  
- Evidence ID  
- Source ID  
- Source type  
- URL or provenance  
- Verbatim quote or extracted fact  
- Detection pattern  
- Timestamp  
- Confidence or evidence status  

Rule: AI may interpret evidence. It may not invent it.

**A — Analysis**  
Explain what the evidence might mean.  
Analysis may produce: themes, root-cause hypotheses, audience interpretations, market possibilities, platform implications, candidate solutions, validation questions, missing-evidence lists.  
Every interpretation remains labeled as a hypothesis unless directly supported.

**P — Prioritization**  
Rank the findings according to the objective.  
Possible factors: evidence strength, frequency, severity, relevance, constraint fit, effort, opportunity value, ability to act, risk, independence or control.  
Output: ranked candidate findings, not an automatic conclusion.

**E — Execution**  
Select the highest-priority viable move and do it.  
Execution may include: testing a platform, publishing content, contacting a potential audience, building a prototype, running a validation experiment, creating a service offer, gathering missing evidence.  
The system must select a primary action instead of endlessly generating alternatives.

**R — Recordkeeping**  
Save what happened.  
Record: decision made, action taken, evidence used, options rejected, results, failures, new evidence, next-cycle implications.  
This prevents the system from restarting from zero or repeating dead ends.

## The operating loop

```
Research
   ↓
Evidence
   ↓
Analysis
   ↓
Prioritization
   ↓
Execution
   ↓
Recordkeeping
   ↺
```

## The three hard rules

1. No evidence, no factual claim.  
2. No decision without prioritization.  
3. No completed cycle without recordkeeping.

## Domain configurations

These are not separate systems. They are REAPER configurations:

- **Gravemark**: finds evidence-backed opportunities.  
- **Pain Signal Harvester**: finds and ranks complaints, friction, and unmet needs.  
- **Personal Brand Framework**: evaluates markets, audiences, platforms, positioning, and content strategy.

Same machine. Different target. Same operating rules.

## Output Contract

Every cycle produces:
- Evidence objects with full provenance
- Analysis labeled as hypotheses
- Ranked candidates
- One primary action
- Recordkeeping entry that can seed the next cycle

Do not invent claims. Do not skip prioritization. Do not end without a record.